﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetMag.Validation.Entidades.Enumeradores
{
    public enum ProfissaoEnum
    {
        Arquiteto = 1,
        Desenvolvedor = 2,
        Analista = 3
    }
}
