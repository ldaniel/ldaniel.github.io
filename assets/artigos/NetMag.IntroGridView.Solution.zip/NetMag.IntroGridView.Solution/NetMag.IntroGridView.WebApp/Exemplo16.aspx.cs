﻿using System;

namespace NetMag.IntroGridView.WebApp
{
    public partial class Exemplo16 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected string GetImagem(string temCartao)
        {
            string ret = "";

            if (temCartao == "True")
                ret = "~/images/cartoes.jpg";
            else if (temCartao == "False")
                ret = "~/images/smile.jpg";

            return ret;
        }
    }
}