﻿using System.Collections.Generic;

namespace NetMag.IntroGridView.WebApp.App_Code.Comun
{
    public static class Dados
    {
        public static List<Entidades.Jogador> ListarJogadores()
        {
            var jogadores = new List<Entidades.Jogador>
                                {
                                    new Entidades.Jogador(18, "Leonardo Moura"),
                                    new Entidades.Jogador(17, "David"),
                                    new Entidades.Jogador(25, "Ronaldo Angelim"),
                                    new Entidades.Jogador(5, "Juan "),
                                    new Entidades.Jogador(22, "Airton"),
                                    new Entidades.Jogador(34, "Toró (Everton)"),
                                    new Entidades.Jogador(11, "Williams"),
                                    new Entidades.Jogador(4, "Petkovic"),
                                    new Entidades.Jogador(10, "Zé Roberto"),
                                    new Entidades.Jogador(1, "Adriano")
                                };

            return jogadores;
        }

        public static Entidades.Time ListarTime()
        {
            return new Entidades.Time(1, "Flamengo", ListarJogadores());
        }
    }
}