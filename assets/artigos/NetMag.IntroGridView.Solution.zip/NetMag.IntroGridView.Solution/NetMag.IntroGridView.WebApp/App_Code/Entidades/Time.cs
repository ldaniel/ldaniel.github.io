﻿using System.Collections.Generic;

namespace NetMag.IntroGridView.WebApp.App_Code.Entidades
{
    public class Time
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public List<Jogador> Jogadores { get; set; }

        public Time (int id, string nome, List<Jogador> jogadores)
        {
            ID = id;
            Nome = nome;
            Jogadores = jogadores;
        }
    }
}