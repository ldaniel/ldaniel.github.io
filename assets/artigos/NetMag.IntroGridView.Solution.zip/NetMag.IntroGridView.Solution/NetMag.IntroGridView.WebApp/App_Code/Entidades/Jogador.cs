﻿namespace NetMag.IntroGridView.WebApp.App_Code.Entidades
{
    public class Jogador
    {
        public int Camisa { get; set; }
        public string Nome { get; set; }

        public Jogador (int camisa, string nome)
        {
            Camisa = camisa;
            Nome = nome;
        }
    }
}