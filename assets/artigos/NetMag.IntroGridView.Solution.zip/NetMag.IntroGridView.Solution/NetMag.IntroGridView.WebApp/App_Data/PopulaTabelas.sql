INSERT INTO [Time] (nome) VALUES ("Flamengo")
GO

INSERT INTO jogador (camisa, nome, idtime) VALUES (18, 'Leonardo Moura', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (17, 'David', 1)
INSERT INTO jogador (camisa, nome, idtime) VALUES (25, 'Ronaldo Angelim', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (5, 'Juan', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (22, 'Airton', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (34, 'Tor� (Everton)', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (11, 'Williams', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (4, 'Petkovic', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (10, 'Z� Roberto', 1) 
INSERT INTO jogador (camisa, nome, idtime) VALUES (1, 'Adriano', 1)
GO