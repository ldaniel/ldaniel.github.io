﻿using System;
using NetMag.IntroGridView.WebApp.Comun;

namespace NetMag.IntroGridView.WebApp
{
    public partial class Exemplo10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
    }
}