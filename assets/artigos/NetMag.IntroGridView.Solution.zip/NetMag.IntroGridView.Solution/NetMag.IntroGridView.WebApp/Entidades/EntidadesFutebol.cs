﻿using System.Collections.Generic;

namespace NetMag.IntroGridView.WebApp.Entidades
{
    public class Jogador
    {
        public int Camisa { get; set; }
        public string Nome { get; set; }

        public Jogador(int camisa, string nome)
        {
            Camisa = camisa;
            Nome = nome;
        }
    }

    public class Time
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public List<Jogador> Jogadores { get; set; }

        public Time(int id, string nome, List<Jogador> jogadores)
        {
            ID = id;
            Nome = nome;
            Jogadores = jogadores;
        }
    }
}