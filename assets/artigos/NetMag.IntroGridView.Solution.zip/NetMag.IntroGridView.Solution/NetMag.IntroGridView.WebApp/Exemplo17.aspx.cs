﻿using System;
using System.Web.UI.WebControls;

namespace NetMag.IntroGridView.WebApp
{
    public partial class Exemplo17 : System.Web.UI.Page
    {
        private static double _total;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                _total = 0;
        }

        protected void Escalacao_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                _total += Convert.ToDouble(e.Row.Cells[3].Text);

            }

            if (e.Row.RowType == DataControlRowType.Footer)
            {
                e.Row.Cells[0].Text = "Quant: " + _total;
            }
        }
    }
}