﻿using System;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Text;

namespace NetMag.IntroGridView.WebApp
{
    public partial class Exemplo12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnItensSelecionados_Click(object sender, EventArgs e)
        {
            var jogadores = new StringBuilder("* Itens Selecionados *");

            foreach (GridViewRow row in Escalacao.Rows)
            {
                var ch = (CheckBox)row.FindControl("CheckBox1");

                if ((ch != null) && (ch.Checked))
                {
                    jogadores.AppendLine();
                    jogadores.Append(row.Cells[1].Text + " - " + row.Cells[0].Text);
                }
            }

            txtSelecao.Text = "";
            txtSelecao.Text = jogadores.ToString();
        }

        protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            //percorre todas as linhas (rows) do GridView
            foreach (GridViewRow row in Escalacao.Rows)
            {
                //procura pelo CheckBox
                var ch = (CheckBox)row.FindControl("CheckBox1");
                //se achou
                if (ch != null)
                {
                    //repassa para o CheckBox das linhas,
                    //o mesmo valor do CheckBox2
                    ch.Checked = (sender as CheckBox).Checked;
                }
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            //percorre todas as linhas (rows) do GridView
            foreach (GridViewRow row in Escalacao.Rows)
            {
                //procura pelo CheckBox
                var ch = (CheckBox)row.FindControl("CheckBox1");
                //se achou
                if (ch != null)
                {
                    if (ch.Checked)
                    {
                        //formata o tamanho, negrito e cor
                        row.Font.Size = 12;
                        row.Font.Bold = true;
                        row.ForeColor = Color.Red;
                    }
                    else
                    {
                        //volta ao padrão
                        row.Font.Size = 12;
                        row.Font.Bold = false;
                        row.ForeColor = Color.Black;
                    }
                }
            }
        }
    }
}