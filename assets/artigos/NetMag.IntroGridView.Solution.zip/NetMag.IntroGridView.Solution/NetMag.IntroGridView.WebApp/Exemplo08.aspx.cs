﻿using System;
using NetMag.IntroGridView.WebApp.Comun;

namespace NetMag.IntroGridView.WebApp
{
    public partial class Exemplo08 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CarregarEscalacao();
            }
        }

        private void CarregarEscalacao()
        {
            Escalacao.DataSource = Dados.ListarJogadores();
            Escalacao.DataBind();
        }
    }
}