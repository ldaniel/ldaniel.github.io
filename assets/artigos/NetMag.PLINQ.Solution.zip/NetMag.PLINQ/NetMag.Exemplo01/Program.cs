﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Número de processadores: {0}", 
            Environment.ProcessorCount);
        Console.ReadLine();
    }
}
